package com.nexus.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** All settings live on this device only (SharedPreferences). */
class AppSettings private constructor(ctx: Context) {
    private val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    var theme by mutableStateOf(sp.getString("theme", "amoled") ?: "amoled")
        private set
    var accent by mutableStateOf(sp.getInt("accent", 0))
        private set
    var compact by mutableStateOf(sp.getBoolean("compact", false))
        private set
    var dailyGoalMin by mutableStateOf(sp.getInt("goal_min", 180))
        private set
    var hidePreviews by mutableStateOf(sp.getBoolean("hide_previews", false))
        private set
    var maskCodes by mutableStateOf(sp.getBoolean("mask_codes", true))
        private set
    var keepDays by mutableStateOf(sp.getInt("keep_days", 30))
        private set
    var autoUpdate by mutableStateOf(sp.getBoolean("auto_update", true))
        private set
    var disabled: Set<String> by mutableStateOf((sp.getStringSet("inbox_off", null) ?: emptySet()).toSet())
        private set
    var favorites: Set<String> by mutableStateOf((sp.getStringSet("favs", null) ?: emptySet()).toSet())
        private set

    fun updateTheme(v: String) { theme = v; sp.edit().putString("theme", v).apply() }
    fun updateAccent(v: Int) { accent = v; sp.edit().putInt("accent", v).apply() }
    fun updateCompact(v: Boolean) { compact = v; sp.edit().putBoolean("compact", v).apply() }
    fun updateDailyGoalMin(v: Int) { dailyGoalMin = v; sp.edit().putInt("goal_min", v).apply() }
    fun updateHidePreviews(v: Boolean) { hidePreviews = v; sp.edit().putBoolean("hide_previews", v).apply() }
    fun updateMaskCodes(v: Boolean) { maskCodes = v; sp.edit().putBoolean("mask_codes", v).apply() }
    fun updateKeepDays(v: Int) { keepDays = v; sp.edit().putInt("keep_days", v).apply() }
    fun updateAutoUpdate(v: Boolean) { autoUpdate = v; sp.edit().putBoolean("auto_update", v).apply() }

    fun isInboxEnabled(id: String): Boolean = id !in disabled
    fun setInboxEnabled(id: String, on: Boolean) {
        val n: Set<String> = if (on) disabled - id else disabled + id
        disabled = n
        sp.edit().putStringSet("inbox_off", n).apply()
    }

    fun toggleFavorite(id: String) {
        val n: Set<String> = if (id in favorites) favorites - id else favorites + id
        favorites = n
        sp.edit().putStringSet("favs", n).apply()
    }

    companion object {
        const val PREFS = "nexus_settings"
        @Volatile private var inst: AppSettings? = null
        fun get(c: Context): AppSettings =
            inst ?: synchronized(this) {
                inst ?: AppSettings(c.applicationContext).also { inst = it }
            }
    }
}
