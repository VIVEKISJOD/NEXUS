package com.nexus.app

import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val s = vm.settings

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenTitle("Settings", "Version ${BuildConfig.VERSION_NAME} (build ${BuildConfig.VERSION_CODE})")

        // ---------- Updates ----------
        SectionLabel("App updates")
        UpdateCard(vm, full = true)
        NCard {
            ToggleRow(
                "Check for updates when Nexus opens",
                "Looks at your GitHub releases. Nothing else is sent.",
                s.autoUpdate
            ) { s.updateAutoUpdate(it) }
        }

        // ---------- Appearance ----------
        SectionLabel("Appearance")
        NCard {
            Text("Theme", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("system" to "System", "dark" to "Dark", "amoled" to "AMOLED black", "light" to "Light")
                    .forEach { (id, label) -> NChip(label, s.theme == id) { s.updateTheme(id) } }
            }
            Spacer(Modifier.height(14.dp))
            Text("Accent colour", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Accents.forEachIndexed { i, c ->
                    val sel = s.accent == i
                    Box(
                        Modifier.size(38.dp).clip(CircleShape).background(c)
                            .then(if (sel) Modifier.border(3.dp, cs.onSurface, CircleShape) else Modifier)
                            .clickable { s.updateAccent(i) }
                    )
                }
            }
            Spacer(Modifier.height(4.dp))
            ToggleRow("Compact layout", "Smaller card padding to fit more on screen", s.compact) { s.updateCompact(it) }
        }

        // ---------- Wellbeing ----------
        SectionLabel("Wellbeing")
        NCard {
            Text("Daily social media goal", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Text(
                "Shown as a progress bar on Home.",
                color = cs.onSurfaceVariant, fontSize = 13.sp
            )
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                NChip("-15m", false) { s.updateDailyGoalMin((s.dailyGoalMin - 15).coerceAtLeast(15)) }
                Spacer(Modifier.width(14.dp))
                Text(fmtDuration(s.dailyGoalMin * 60_000L), fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.width(14.dp))
                NChip("+15m", false) { s.updateDailyGoalMin((s.dailyGoalMin + 15).coerceAtMost(720)) }
            }
        }

        // ---------- Inbox & notifications ----------
        SectionLabel("Inbox and notifications")
        NCard {
            Text("Collect notifications from", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Text(
                "Turn an app off and Nexus stops saving its notifications. Your phone's own notifications are not changed.",
                color = cs.onSurfaceVariant, fontSize = 13.sp
            )
            Platforms.all.filter { it.inbox }.forEach { p ->
                ToggleRow(p.name, null, s.isInboxEnabled(p.id)) { s.setInboxEnabled(p.id, it); vm.refreshInbox() }
            }
        }
        NCard {
            ToggleRow(
                "Hide all message previews",
                "Inbox shows \"Message hidden\" instead of the text",
                s.hidePreviews
            ) { s.updateHidePreviews(it) }
            ToggleRow(
                "Hide codes and passwords",
                "Hides messages that look like OTP or verification codes",
                s.maskCodes
            ) { s.updateMaskCodes(it) }
        }
        NCard {
            Text("Keep notification history for", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(7 to "7 days", 30 to "30 days", 90 to "90 days", 0 to "Forever").forEach { (d, label) ->
                    NChip(label, s.keepDays == d) { s.updateKeepDays(d); vm.cleanOld() }
                }
            }
            Spacer(Modifier.height(12.dp))
            Button(onClick = { vm.clearHistory() }) { Text("Clear notification history now", fontWeight = FontWeight.Bold) }
        }

        // ---------- Permissions ----------
        SectionLabel("Permissions")
        PermRow(
            "Usage access", "Reads how long you use social apps", vm.usageAccess
        ) { openSettingsScreen(ctx, Settings.ACTION_USAGE_ACCESS_SETTINGS) }
        PermRow(
            "Notification access", "Lets Nexus build the Inbox", vm.notifAccess
        ) { openSettingsScreen(ctx, Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) }
        PermRow(
            "Install updates", "Lets Nexus hand updates to Android's installer", vm.canInstall
        ) { openSettingsScreen(ctx, Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, withPackage = true) }

        // ---------- About ----------
        SectionLabel("About")
        NCard {
            Text("Your data stays on this phone", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(4.dp))
            Text(
                "Nexus has no server and no account. Usage numbers, notification history and settings are stored only on this device. The only internet use is checking GitHub for app updates.",
                color = cs.onSurfaceVariant, fontSize = 14.sp
            )
            Spacer(Modifier.height(8.dp))
            Text("Update source: ${BuildConfig.GITHUB_REPO}", color = cs.onSurfaceVariant, fontSize = 13.sp)
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun PermRow(title: String, sub: String, granted: Boolean, onOpen: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    NCard(onClick = onOpen) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Text(sub, color = cs.onSurfaceVariant, fontSize = 13.sp)
            }
            Spacer(Modifier.width(10.dp))
            Pill(if (granted) "On" else "Off", if (granted) cs.primary else cs.error)
        }
    }
}
