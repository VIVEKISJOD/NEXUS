Step 1b: fixes the build error. Home usage dashboard, Inbox from notifications, Social shortcuts, Settings, in-app updates.
