plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Filled in automatically by the GitHub build (see .github/workflows/build.yml)
val ghRepo: String = (project.findProperty("GITHUB_REPO") as String?) ?: "OWNER/REPO"
val vCode: Int = (project.findProperty("VERSION_CODE") as String?)?.toIntOrNull() ?: 1

android {
    namespace = "com.nexus.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.nexus.app"
        minSdk = 26
        targetSdk = 34
        versionCode = vCode
        versionName = "1.0.$vCode"
        buildConfigField("String", "GITHUB_REPO", "\"$ghRepo\"")
    }

    // Same key every build, so updates install over the old app.
    signingConfigs {
        create("nexus") {
            storeFile = file("nexus-release.jks")
            storePassword = "nexus-pass-1"
            keyAlias = "nexus"
            keyPassword = "nexus-pass-1"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("nexus")
        }
        debug {
            signingConfig = signingConfigs.getByName("nexus")
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
}
