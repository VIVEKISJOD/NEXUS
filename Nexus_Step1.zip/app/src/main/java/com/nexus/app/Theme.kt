package com.nexus.app

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

val Accents = listOf(
    Color(0xFFB6F26B), // Lime
    Color(0xFF7DB8F0), // Sky
    Color(0xFFE1A0C8), // Pink
    Color(0xFFE89B6B), // Orange
    Color(0xFF9F8CFF), // Violet
    Color(0xFF5EEAD4)  // Mint
)
val AccentNames = listOf("Lime", "Sky", "Pink", "Orange", "Violet", "Mint")

val LocalCompact = compositionLocalOf { false }

@Composable
fun NexusTheme(s: AppSettings, content: @Composable () -> Unit) {
    val sysDark = isSystemInDarkTheme()
    val dark = when (s.theme) {
        "light" -> false
        "system" -> sysDark
        else -> true
    }
    val amoled = s.theme == "amoled"
    val accent = Accents[s.accent.coerceIn(0, Accents.lastIndex)]

    val scheme = if (dark) {
        val bg = if (amoled) Color(0xFF000000) else Color(0xFF12141A)
        darkColorScheme(
            primary = accent,
            onPrimary = Color(0xFF10140A),
            background = bg,
            surface = bg,
            surfaceVariant = if (amoled) Color(0xFF16181F) else Color(0xFF20242E),
            onSurface = Color(0xFFF2F3F5),
            onBackground = Color(0xFFF2F3F5),
            onSurfaceVariant = Color(0xFF9AA0AD),
            outline = Color(0xFF343A47),
            error = Color(0xFFFF8A80)
        )
    } else {
        lightColorScheme(
            primary = Color(0xFF3D6B00),
            onPrimary = Color(0xFFFFFFFF),
            background = Color(0xFFF4F5F7),
            surface = Color(0xFFF4F5F7),
            surfaceVariant = Color(0xFFFFFFFF),
            onSurface = Color(0xFF14161B),
            onBackground = Color(0xFF14161B),
            onSurfaceVariant = Color(0xFF5E6573),
            outline = Color(0xFFD5D9E0),
            error = Color(0xFFC62828)
        )
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val w = (view.context as Activity).window
            val ctrl = WindowCompat.getInsetsController(w, view)
            ctrl.isAppearanceLightStatusBars = !dark
            ctrl.isAppearanceLightNavigationBars = !dark
        }
    }

    CompositionLocalProvider(LocalCompact provides s.compact) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
