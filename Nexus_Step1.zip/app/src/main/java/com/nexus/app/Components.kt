package com.nexus.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------- helpers ----------

fun fmtDuration(ms: Long): String {
    val m = ms / 60000
    return when {
        ms <= 0 -> "0m"
        m < 1 -> "<1m"
        m >= 60 -> "${m / 60}h ${m % 60}m"
        else -> "${m}m"
    }
}

fun fmtAgo(t: Long): String {
    val m = (System.currentTimeMillis() - t) / 60000
    return when {
        m < 1 -> "now"
        m < 60 -> "${m}m"
        m < 1440 -> "${m / 60}h"
        else -> "${m / 1440}d"
    }
}

fun hourLabel(h: Int): String {
    val h12 = if (h % 12 == 0) 12 else h % 12
    return "$h12 " + (if (h < 12) "AM" else "PM")
}

private val codeRegex = Regex("\\b\\d{4,8}\\b")
private val codeWords = Regex("(?i)otp|code|verification|password|pin|passcode")

fun previewText(raw: String, hideAll: Boolean, maskCodes: Boolean): String {
    if (hideAll) return "Message hidden"
    if (maskCodes && codeRegex.containsMatchIn(raw) && codeWords.containsMatchIn(raw)) {
        return "Sensitive message hidden"
    }
    return raw
}

fun openPlatform(ctx: Context, p: Platform) {
    try {
        val launch = ctx.packageManager.getLaunchIntentForPackage(p.packageName)
        if (launch != null) {
            ctx.startActivity(launch)
        } else {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(p.url)))
        }
    } catch (e: Exception) {
        Toast.makeText(ctx, "Can't open ${p.name}", Toast.LENGTH_SHORT).show()
    }
}

fun openSettingsScreen(ctx: Context, action: String, withPackage: Boolean = false) {
    try {
        val i = Intent(action)
        if (withPackage) i.data = Uri.parse("package:" + ctx.packageName)
        ctx.startActivity(i)
    } catch (e: Exception) {
        Toast.makeText(ctx, "Can't open that settings page on this phone", Toast.LENGTH_LONG).show()
    }
}

// ---------- building blocks ----------

@Composable
fun NCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val pad = if (LocalCompactValue()) 12.dp else 18.dp
    val base = modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(24.dp))
        .background(MaterialTheme.colorScheme.surfaceVariant)
    val clickable = if (onClick != null) base.clickable(onClick = onClick) else base
    Column(modifier = clickable.padding(pad), content = content)
}

@Composable
private fun LocalCompactValue(): Boolean = LocalCompact.current

@Composable
fun ScreenTitle(title: String, sub: String? = null) {
    Column(Modifier.padding(top = 8.dp, bottom = 2.dp)) {
        Text(title, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
        if (sub != null) {
            Text(sub, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 15.sp)
        }
    }
}

@Composable
fun SectionLabel(text: String) {
    Text(
        text.uppercase(),
        color = MaterialTheme.colorScheme.primary,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(top = 10.dp, bottom = 2.dp, start = 4.dp)
    )
}

@Composable
fun NChip(text: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) cs.primary else cs.surfaceVariant)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 9.dp)
    ) {
        Text(
            text,
            color = if (selected) cs.onPrimary else cs.onSurface,
            fontWeight = FontWeight.SemiBold,
            fontSize = 14.sp
        )
    }
}

@Composable
fun Pill(text: String, color: Color) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.18f))
            .padding(horizontal = 12.dp, vertical = 5.dp)
    ) {
        Text(text, color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun BarRow(name: String, value: String, fraction: Float, color: Color) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.padding(vertical = 6.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Text(value, color = cs.onSurfaceVariant, fontSize = 15.sp)
        }
        Spacer(Modifier.height(6.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(cs.outline.copy(alpha = 0.6f))
        ) {
            Box(
                Modifier
                    .fillMaxWidth(fraction.coerceIn(0.03f, 1f))
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(4.dp))
                    .background(color)
            )
        }
    }
}

@Composable
fun ToggleRow(title: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onChange(!checked) }
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            if (sub != null) {
                Text(sub, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun PermissionCard(title: String, body: String, button: String, onClick: () -> Unit) {
    NCard {
        Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text(body, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
        Spacer(Modifier.height(12.dp))
        Button(onClick = onClick) { Text(button, fontWeight = FontWeight.Bold) }
    }
}

@Composable
fun UpdateCard(vm: MainViewModel, full: Boolean) {
    val cs = MaterialTheme.colorScheme
    val u = vm.update

    if (!full && u !is UpdateState.Available && u !is UpdateState.Downloading && u !is UpdateState.Ready) return

    NCard {
        when (u) {
            is UpdateState.Available -> {
                Text("Update available", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("Build ${u.info.build}", color = cs.primary, fontWeight = FontWeight.SemiBold)
                if (u.info.notes.isNotBlank()) {
                    Spacer(Modifier.height(6.dp))
                    Text(u.info.notes.take(300), color = cs.onSurfaceVariant, fontSize = 14.sp)
                }
                if (!vm.canInstall) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Android will ask you to allow Nexus to install updates. Tap Allow, then come back and press the button again.",
                        color = cs.onSurfaceVariant, fontSize = 13.sp
                    )
                }
                Spacer(Modifier.height(12.dp))
                Button(onClick = { vm.startDownload(u.info) }) {
                    Text("Download and install", fontWeight = FontWeight.Bold)
                }
            }
            is UpdateState.Downloading -> {
                Text("Downloading update… ${u.percent}%", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(progress = { u.percent / 100f }, modifier = Modifier.fillMaxWidth())
            }
            is UpdateState.Ready -> {
                Text("Update ready", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Button(onClick = { vm.installNow(u.file) }) { Text("Install now", fontWeight = FontWeight.Bold) }
            }
            is UpdateState.Checking -> {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(modifier = Modifier.height(22.dp).width(22.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(12.dp))
                    Text("Checking GitHub…")
                }
            }
            is UpdateState.UpToDate -> {
                Text("You have the latest build", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                Button(onClick = { vm.checkUpdate(true) }) { Text("Check again") }
            }
            is UpdateState.Error -> {
                Text("Update check failed", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = cs.error)
                Spacer(Modifier.height(4.dp))
                Text(u.msg, color = cs.onSurfaceVariant, fontSize = 14.sp)
                Spacer(Modifier.height(10.dp))
                Button(onClick = { vm.checkUpdate(true) }) { Text("Try again") }
            }
            is UpdateState.Idle -> {
                Button(onClick = { vm.checkUpdate(true) }) { Text("Check for updates", fontWeight = FontWeight.Bold) }
            }
        }
    }
}
