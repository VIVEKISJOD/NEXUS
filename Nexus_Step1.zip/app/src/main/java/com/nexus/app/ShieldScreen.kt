package com.nexus.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ShieldScreen() {
    val cs = MaterialTheme.colorScheme
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { ScreenTitle("Shield", "Ad and tracker blocking") }
        item {
            NCard {
                Pill("Not active yet", cs.error)
                Spacer(Modifier.height(10.dp))
                Text("Nothing is being blocked", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Shield arrives in Step 2. Until then Nexus blocks nothing and shows no blocking numbers.",
                    color = cs.onSurfaceVariant, fontSize = 14.sp
                )
            }
        }
        item {
            NCard {
                Text("What Step 2 will add", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "A local VPN on your phone that checks website names (DNS) against blocklists. Ad, tracker and custom blocklists, allow list, and real blocked counts. Nothing leaves your phone.",
                    color = cs.onSurfaceVariant, fontSize = 14.sp
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "Honest limit: ads that come from the same website name as the content (like many in-app Instagram or YouTube ads) cannot be blocked this way.",
                    color = cs.onSurfaceVariant, fontSize = 14.sp
                )
            }
        }
    }
}
