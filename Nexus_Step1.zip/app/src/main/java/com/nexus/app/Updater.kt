package com.nexus.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class UpdateInfo(
    val tag: String,
    val build: Int,
    val notes: String,
    val apkUrl: String,
    val sizeBytes: Long
)

sealed interface UpdateState {
    object Idle : UpdateState
    object Checking : UpdateState
    object UpToDate : UpdateState
    data class Available(val info: UpdateInfo) : UpdateState
    data class Downloading(val percent: Int) : UpdateState
    data class Ready(val file: File) : UpdateState
    data class Error(val msg: String) : UpdateState
}

/**
 * Reads the newest GitHub Release of your repo. The build workflow publishes
 * a release named build-<number> with Nexus.apk every time you push.
 */
object Updater {

    suspend fun check(): UpdateInfo = withContext(Dispatchers.IO) {
        val url = URL("https://api.github.com/repos/${BuildConfig.GITHUB_REPO}/releases/latest")
        val c = url.openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.setRequestProperty("User-Agent", "Nexus-Updater")
        try {
            val code = c.responseCode
            if (code == 404) throw IOException("No release found yet. The GitHub repo must be public and its build must be finished.")
            if (code != 200) throw IOException("GitHub answered with code $code")
            val body = c.inputStream.bufferedReader().use { it.readText() }
            val j = JSONObject(body)
            val tag = j.optString("tag_name")
            val build = tag.filter { it.isDigit() }.toIntOrNull() ?: 0
            val notes = j.optString("body")
            val assets = j.optJSONArray("assets")
            var apk = ""
            var size = 0L
            if (assets != null) {
                for (i in 0 until assets.length()) {
                    val a = assets.getJSONObject(i)
                    if (a.optString("name").endsWith(".apk")) {
                        apk = a.optString("browser_download_url")
                        size = a.optLong("size")
                        break
                    }
                }
            }
            if (apk.isEmpty()) throw IOException("The latest release has no APK file.")
            UpdateInfo(tag, build, notes, apk, size)
        } finally {
            c.disconnect()
        }
    }

    suspend fun download(ctx: Context, info: UpdateInfo, onProgress: (Int) -> Unit): File =
        withContext(Dispatchers.IO) {
            val dir = File(ctx.cacheDir, "updates")
            dir.mkdirs()
            val f = File(dir, "nexus-update.apk")
            if (f.exists()) f.delete()
            val c = URL(info.apkUrl).openConnection() as HttpURLConnection
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "Nexus-Updater")
            try {
                if (c.responseCode != 200) throw IOException("Download failed (code ${c.responseCode})")
                val total = if (c.contentLengthLong > 0) c.contentLengthLong else info.sizeBytes
                var done = 0L
                var last = -1
                c.inputStream.use { input ->
                    f.outputStream().use { out ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            if (total > 0) {
                                val pct = ((done * 100) / total).toInt().coerceIn(0, 100)
                                if (pct != last) {
                                    last = pct
                                    onProgress(pct)
                                }
                            }
                        }
                    }
                }
                f
            } finally {
                c.disconnect()
            }
        }

    /** Returns false when Android first needs you to allow installs from Nexus. */
    fun install(ctx: Context, apk: File): Boolean {
        if (!ctx.packageManager.canRequestPackageInstalls()) {
            val i = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            return false
        }
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", apk)
        val i = Intent(Intent.ACTION_VIEW)
        i.setDataAndType(uri, "application/vnd.android.package-archive")
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return true
    }
}
