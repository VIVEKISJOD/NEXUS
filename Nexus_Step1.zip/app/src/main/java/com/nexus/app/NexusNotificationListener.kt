package com.nexus.app

import android.app.Notification
import android.content.Context
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Reads notifications from supported social apps and keeps a copy on this device.
 * It never sends anything anywhere. It only sees what Android shows in the notification shade.
 */
class NexusNotificationListener : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            val pkg = sbn.packageName ?: return
            if (pkg == packageName) return
            val platform = Platforms.byPackage(pkg) ?: return

            val off = getSharedPreferences(AppSettings.PREFS, Context.MODE_PRIVATE)
                .getStringSet("inbox_off", null) ?: emptySet()
            if (platform.id in off) return

            val n = sbn.notification ?: return
            if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
            if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return

            val extras = n.extras ?: return
            val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty().trim()
            val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
                ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty().trim()
            if (title.isEmpty() && text.isEmpty()) return

            val isGroup = extras.getBoolean("android.isGroupConversation", false)
            val convo = if (title.isEmpty()) platform.name else title

            NotificationStore.get(this).insert(
                pkg, convo, text, sbn.postTime, isGroup, sbn.key ?: (pkg + convo)
            )
        } catch (e: Exception) {
            // Never crash the listener
        }
    }
}
