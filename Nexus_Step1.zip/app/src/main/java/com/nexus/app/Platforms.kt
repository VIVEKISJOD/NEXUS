package com.nexus.app

data class Platform(
    val id: String,
    val name: String,
    val packageName: String,
    val url: String,
    val color: Long,
    val inbox: Boolean
)

object Platforms {
    val all = listOf(
        Platform("instagram", "Instagram", "com.instagram.android", "https://www.instagram.com", 0xFFE1A0C8, true),
        Platform("facebook", "Facebook", "com.facebook.katana", "https://www.facebook.com", 0xFF6C8CF0, true),
        Platform("messenger", "Messenger", "com.facebook.orca", "https://www.messenger.com", 0xFF5AA9F5, true),
        Platform("whatsapp", "WhatsApp", "com.whatsapp", "https://web.whatsapp.com", 0xFF4ADE80, true),
        Platform("telegram", "Telegram", "org.telegram.messenger", "https://web.telegram.org", 0xFF7DB8F0, true),
        Platform("youtube", "YouTube", "com.google.android.youtube", "https://www.youtube.com", 0xFFE57373, false),
        Platform("reddit", "Reddit", "com.reddit.frontpage", "https://www.reddit.com", 0xFFE89B6B, true),
        Platform("x", "X", "com.twitter.android", "https://x.com", 0xFFE6E6E6, true),
        Platform("snapchat", "Snapchat", "com.snapchat.android", "https://www.snapchat.com", 0xFFFFE04D, true),
        Platform("discord", "Discord", "com.discord", "https://discord.com/app", 0xFF8E9BFF, true),
        Platform("pinterest", "Pinterest", "com.pinterest", "https://www.pinterest.com", 0xFFE05A5A, false),
        Platform("linkedin", "LinkedIn", "com.linkedin.android", "https://www.linkedin.com", 0xFF5B9BD5, false),
        Platform("threads", "Threads", "com.instagram.barcelona", "https://www.threads.net", 0xFFCCCCCC, false),
        Platform("mastodon", "Mastodon", "org.joinmastodon.android", "https://joinmastodon.org", 0xFF9F8CFF, false)
    )

    fun byPackage(pkg: String): Platform? = all.firstOrNull { it.packageName == pkg }
    fun byId(id: String): Platform? = all.firstOrNull { it.id == id }
}
