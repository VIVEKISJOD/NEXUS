package com.nexus.app

import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun InboxScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var filter by rememberSaveable { mutableStateOf("All") }
    var platformId by rememberSaveable { mutableStateOf("") }
    var query by rememberSaveable { mutableStateOf("") }
    val s = vm.settings

    val all = vm.convos.filter { c ->
        val p = Platforms.byPackage(c.pkg)
        p != null && p.inbox && s.isInboxEnabled(p.id)
    }
    val list = all
        .filter {
            when (filter) {
                "Unread" -> it.unread > 0
                "Personal" -> !it.isGroup
                "Groups" -> it.isGroup
                else -> true
            }
        }
        .filter { platformId.isEmpty() || Platforms.byPackage(it.pkg)?.id == platformId }
        .filter {
            query.isBlank() || it.name.contains(query, ignoreCase = true) ||
                it.last.contains(query, ignoreCase = true)
        }
    val unreadTotal = all.sumOf { it.unread }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) { ScreenTitle("Inbox", "Notification previews from your apps") }
                if (unreadTotal > 0) Pill("$unreadTotal unread", cs.primary)
            }
        }
        item {
            NCard {
                Text(
                    "This inbox is built from notifications Android already shows you. It is not a real chat connection, so you cannot reply here. Tap a conversation to open the real app.",
                    color = cs.onSurfaceVariant, fontSize = 13.sp
                )
            }
        }

        if (!vm.notifAccess) {
            item {
                PermissionCard(
                    "Allow notification access",
                    "Nexus reads the notifications that social apps show, and keeps them only on this phone. Nothing is uploaded. Turn on Nexus on the next screen.\n\nIf the switch is greyed out: open Android Settings, Apps, Nexus, tap the three dots at the top right, and choose Allow restricted settings. Then try again.",
                    "Open notification access settings"
                ) { openSettingsScreen(ctx, Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) }
            }
        } else {
            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    placeholder = { Text("Search conversations") },
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            item {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("All", "Unread", "Personal", "Groups").forEach { f ->
                        NChip(f, filter == f) { filter = f }
                    }
                }
            }
            item {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NChip("All apps", platformId.isEmpty()) { platformId = "" }
                    Platforms.all.filter { it.inbox && s.isInboxEnabled(it.id) }.forEach { p ->
                        NChip(p.name, platformId == p.id) { platformId = if (platformId == p.id) "" else p.id }
                    }
                }
            }
            if (unreadTotal > 0) {
                item {
                    Text(
                        "Mark all as read",
                        color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                        modifier = Modifier.clickable { vm.markAllRead() }.padding(vertical = 4.dp)
                    )
                }
            }
            if (list.isEmpty()) {
                item {
                    NCard {
                        Text(
                            if (all.isEmpty()) "Nothing here yet" else "No conversations match",
                            fontSize = 18.sp, fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            if (all.isEmpty())
                                "New notifications from your apps will appear here from now on. Nexus cannot read old ones."
                            else "Try another filter or search.",
                            color = cs.onSurfaceVariant, fontSize = 14.sp
                        )
                    }
                }
            } else {
                items(list, key = { it.pkg + "|" + it.name }) { c ->
                    val p = Platforms.byPackage(c.pkg)
                    val color = Color(p?.color ?: 0xFFFFFFFF)
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(cs.surfaceVariant)
                            .clickable {
                                vm.markRead(c)
                                if (p != null) openPlatform(ctx, p)
                            }
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(46.dp).clip(CircleShape).background(color.copy(alpha = 0.22f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                c.name.take(1).uppercase(), color = color,
                                fontWeight = FontWeight.ExtraBold, fontSize = 20.sp
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    c.name, fontWeight = if (c.unread > 0) FontWeight.ExtraBold else FontWeight.SemiBold,
                                    fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(fmtAgo(c.time), color = cs.onSurfaceVariant, fontSize = 12.sp)
                            }
                            Text(
                                previewText(c.last, s.hidePreviews, s.maskCodes),
                                color = cs.onSurfaceVariant, fontSize = 14.sp,
                                maxLines = 2, overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                (p?.name ?: "") + if (c.isGroup) " - group" else "",
                                color = color, fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                            )
                        }
                        if (c.unread > 0) {
                            Spacer(Modifier.width(10.dp))
                            Box(
                                Modifier.clip(CircleShape).background(cs.primary).size(24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    if (c.unread > 99) "99" else c.unread.toString(),
                                    color = cs.onPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
