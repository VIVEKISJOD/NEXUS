package com.nexus.app

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.provider.Settings

@Composable
fun HomeScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val usage = vm.usage

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(cs.primary),
                    contentAlignment = Alignment.Center
                ) {
                    Text("N", color = cs.onPrimary, fontWeight = FontWeight.Black, fontSize = 24.sp)
                }
                Spacer(Modifier.width(12.dp))
                Text("NEXUS", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
        item { ScreenTitle("Your digital day", "Social apps only, today") }
        item { UpdateCard(vm, full = false) }

        if (!vm.usageAccess) {
            item {
                PermissionCard(
                    "Allow usage access",
                    "Nexus needs this to read how long you use social apps. Android keeps this data on your phone and Nexus does not send it anywhere. On the next screen find Nexus and turn it on.",
                    "Open usage access settings"
                ) { openSettingsScreen(ctx, Settings.ACTION_USAGE_ACCESS_SETTINGS) }
            }
        } else if (usage == null) {
            item { NCard { Text("Reading your usage…", color = cs.onSurfaceVariant) } }
        } else {
            item {
                val total = usage.totalMs
                val goalMs = vm.settings.dailyGoalMin * 60_000L
                val frac = if (goalMs > 0) (total.toFloat() / goalMs).coerceIn(0f, 1f) else 0f
                val over = goalMs > 0 && total > goalMs
                val diff = total - usage.yesterdayTotalMs
                NCard {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Total social usage", color = cs.onSurfaceVariant, fontSize = 15.sp)
                        Text("TODAY", color = cs.primary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Text(fmtDuration(total), fontSize = 44.sp, fontWeight = FontWeight.ExtraBold)
                    Text(
                        "Goal ${fmtDuration(goalMs)}" + if (over) " - passed" else "",
                        color = if (over) cs.error else cs.onSurfaceVariant, fontSize = 14.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    Box(
                        Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp))
                            .background(cs.outline.copy(alpha = 0.6f))
                    ) {
                        Box(
                            Modifier.fillMaxWidth(frac.coerceAtLeast(0.01f)).fillMaxHeight()
                                .clip(RoundedCornerShape(5.dp))
                                .background(if (over) cs.error else cs.primary)
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    val cmp = when {
                        usage.yesterdayTotalMs == 0L && total == 0L -> "No usage recorded yet"
                        diff > 0 -> fmtDuration(diff) + " more than yesterday"
                        diff < 0 -> fmtDuration(-diff) + " less than yesterday"
                        else -> "Same as yesterday"
                    }
                    Text(cmp, color = cs.onSurfaceVariant, fontSize = 14.sp)
                    Spacer(Modifier.height(12.dp))
                    if (usage.today.isEmpty()) {
                        Text("No social app use recorded today yet.", color = cs.onSurfaceVariant)
                    } else {
                        val max = usage.today.first().timeMs.toFloat().coerceAtLeast(1f)
                        usage.today.forEach { a ->
                            val p = Platforms.byPackage(a.pkg)
                            BarRow(a.name, fmtDuration(a.timeMs), a.timeMs / max, Color(p?.color ?: 0xFFFFFFFF))
                        }
                    }
                }
            }
            item {
                val avg = if (usage.opens > 0) usage.totalMs / usage.opens else 0L
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard(Modifier.weight(1f), usage.opens.toString(), "App opens")
                    StatCard(Modifier.weight(1f), fmtDuration(avg), "Avg session")
                    StatCard(
                        Modifier.weight(1f),
                        if (vm.notifAccess) vm.notesToday.toString() else "-",
                        "Notifications"
                    )
                }
            }
            item {
                NCard {
                    Text("Last 7 days", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    val maxW = usage.weekTotals.maxOrNull()?.toFloat()?.coerceAtLeast(1f) ?: 1f
                    Row(Modifier.fillMaxWidth().height(110.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        usage.weekTotals.forEachIndexed { i, t ->
                            Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.BottomCenter) {
                                Box(
                                    Modifier.fillMaxWidth(0.7f)
                                        .fillMaxHeight((t / maxW).coerceIn(0.04f, 1f))
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (i == usage.weekTotals.lastIndex) cs.primary else cs.outline)
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        usage.weekLabels.forEach { l ->
                            Text(
                                l.take(3), Modifier.weight(1f), color = cs.onSurfaceVariant, fontSize = 12.sp,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                    val peak = usage.peakHour
                    if (peak != null) {
                        Spacer(Modifier.height(12.dp))
                        Text(
                            "Most distracting hour this week: ${hourLabel(peak)} - ${hourLabel((peak + 1) % 24)}",
                            color = cs.onSurfaceVariant, fontSize = 14.sp
                        )
                    }
                }
            }
        }

        item {
            NCard {
                Text("Reels and Shorts counter", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Not active yet. Android does not tell apps which Reel or Short you are watching, so Nexus shows no short-video numbers for now. A later step adds an optional Accessibility service that you switch on yourself.",
                    color = cs.onSurfaceVariant, fontSize = 14.sp
                )
            }
        }
    }
}

@Composable
private fun StatCard(modifier: Modifier, value: String, label: String) {
    NCard(modifier) {
        Text(value, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
    }
}
