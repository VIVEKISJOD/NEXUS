package com.nexus.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SocialScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    var query by remember { mutableStateOf("") }
    val installed = remember {
        Platforms.all.filter { ctx.packageManager.getLaunchIntentForPackage(it.packageName) != null }
            .map { it.id }.toSet()
    }
    val favs = vm.settings.favorites
    val list = Platforms.all
        .filter { query.isBlank() || it.name.contains(query, ignoreCase = true) }
        .sortedByDescending { it.id in favs }

    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) { ScreenTitle("Social", "Open your apps from one place") }
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    placeholder = { Text("Search platforms") },
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                NCard {
                    Text(
                        "These are shortcuts. Nexus opens the real app (or the website if the app is not installed). Showing platform feeds inside Nexus needs each platform's official login, which is not built yet. Tap the star to pin a favourite.",
                        color = cs.onSurfaceVariant, fontSize = 13.sp
                    )
                }
            }
        }
        items(list, key = { it.id }) { p ->
            val isInstalled = p.id in installed
            val isFav = p.id in favs
            Box(
                Modifier.clip(RoundedCornerShape(22.dp)).background(cs.surfaceVariant)
                    .clickable { openPlatform(ctx, p) }.padding(vertical = 14.dp, horizontal = 6.dp)
            ) {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier.size(46.dp).clip(CircleShape).background(Color(p.color).copy(alpha = 0.22f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(p.name.take(1), color = Color(p.color), fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(p.name, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, textAlign = TextAlign.Center)
                    Text(
                        if (isInstalled) "Installed" else "Opens website",
                        color = if (isInstalled) cs.primary else cs.onSurfaceVariant, fontSize = 11.sp
                    )
                }
                Text(
                    if (isFav) "★" else "☆",
                    color = if (isFav) cs.primary else cs.onSurfaceVariant,
                    fontSize = 20.sp,
                    modifier = Modifier.align(Alignment.TopEnd).clickable { vm.settings.toggleFavorite(p.id) }
                        .padding(horizontal = 6.dp)
                )
            }
        }
    }
}
