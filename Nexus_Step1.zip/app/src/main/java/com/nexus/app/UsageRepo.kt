package com.nexus.app

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Build
import android.os.Process
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class AppUsage(val pkg: String, val name: String, val timeMs: Long, val opens: Int)

data class UsageSummary(
    val today: List<AppUsage>,
    val yesterdayTotalMs: Long,
    val weekTotals: List<Long>,
    val weekLabels: List<String>,
    val peakHour: Int?
) {
    val totalMs: Long get() = today.sumOf { it.timeMs }
    val opens: Int get() = today.sumOf { it.opens }
}

/** Real numbers from Android's UsageStats. Nothing is estimated or invented. */
object UsageRepo {

    @Suppress("DEPRECATION")
    fun hasAccess(ctx: Context): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        } else {
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun dayStart(daysAgo: Int): Long {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        c.add(Calendar.DAY_OF_YEAR, -daysAgo)
        return c.timeInMillis
    }

    fun summary(ctx: Context): UsageSummary {
        val now = System.currentTimeMillis()
        val hours = LongArray(24)
        val totals = ArrayList<Long>()
        val labels = ArrayList<String>()
        var today: List<AppUsage> = emptyList()
        val fmt = SimpleDateFormat("EEE", Locale.getDefault())
        for (i in 6 downTo 0) {
            val s = dayStart(i)
            val e = if (i == 0) now else dayStart(i - 1)
            val list = compute(ctx, s, e, hours)
            totals.add(list.sumOf { it.timeMs })
            labels.add(fmt.format(Date(s)))
            if (i == 0) today = list
        }
        var peak: Int? = null
        var best = 0L
        for (h in 0 until 24) {
            if (hours[h] > best) {
                best = hours[h]
                peak = h
            }
        }
        return UsageSummary(today, totals[5], totals, labels, peak)
    }

    private fun addHours(h: LongArray, s: Long, e: Long) {
        val c = Calendar.getInstance()
        var t = s
        while (t < e) {
            c.timeInMillis = t
            val hr = c.get(Calendar.HOUR_OF_DAY)
            c.set(Calendar.MINUTE, 0)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            c.add(Calendar.HOUR_OF_DAY, 1)
            val next = minOf(c.timeInMillis, e)
            h[hr] += next - t
            t = next
        }
    }

    @Suppress("DEPRECATION")
    private fun compute(ctx: Context, start: Long, end: Long, hours: LongArray?): List<AppUsage> {
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val events = usm.queryEvents(start, end) ?: return emptyList()
        val ev = UsageEvents.Event()
        val since = HashMap<String, Long>()
        val time = HashMap<String, Long>()
        val opens = HashMap<String, Int>()

        fun close(p: String, at: Long) {
            val s = since.remove(p) ?: return
            val d = at - s
            if (d > 0) {
                time[p] = (time[p] ?: 0L) + d
                if (hours != null) addHours(hours, s, at)
            }
        }

        while (events.hasNextEvent()) {
            events.getNextEvent(ev)
            val p = ev.packageName ?: continue
            if (Platforms.byPackage(p) == null) continue
            when (ev.eventType) {
                UsageEvents.Event.MOVE_TO_FOREGROUND -> {
                    if (!since.containsKey(p)) {
                        since[p] = ev.timeStamp
                        opens[p] = (opens[p] ?: 0) + 1
                    }
                }
                UsageEvents.Event.MOVE_TO_BACKGROUND -> close(p, ev.timeStamp)
            }
        }
        for (p in since.keys.toList()) close(p, end)

        return time.map { (p, t) ->
            AppUsage(p, Platforms.byPackage(p)?.name ?: p, t, opens[p] ?: 0)
        }.sortedByDescending { it.timeMs }
    }
}
