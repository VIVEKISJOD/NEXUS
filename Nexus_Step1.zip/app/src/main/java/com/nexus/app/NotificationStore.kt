package com.nexus.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Convo(
    val pkg: String,
    val name: String,
    val last: String,
    val time: Long,
    val isGroup: Boolean,
    val unread: Int
)

/** Notification history kept only on this device. */
class NotificationStore private constructor(ctx: Context) :
    SQLiteOpenHelper(ctx, "nexus.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE notes(id INTEGER PRIMARY KEY AUTOINCREMENT, pkg TEXT NOT NULL, " +
                "convo TEXT NOT NULL, text TEXT NOT NULL, time INTEGER NOT NULL, " +
                "grp INTEGER NOT NULL, unread INTEGER NOT NULL, skey TEXT NOT NULL)"
        )
        db.execSQL("CREATE INDEX idx_notes_time ON notes(time)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun insert(pkg: String, convo: String, text: String, time: Long, group: Boolean, skey: String) {
        val db = writableDatabase
        val same = db.rawQuery(
            "SELECT text FROM notes WHERE skey=? ORDER BY id DESC LIMIT 1", arrayOf(skey)
        ).use { it.moveToFirst() && it.getString(0) == text }
        if (same) return
        val v = ContentValues()
        v.put("pkg", pkg)
        v.put("convo", convo)
        v.put("text", text)
        v.put("time", time)
        v.put("grp", if (group) 1 else 0)
        v.put("unread", 1)
        v.put("skey", skey)
        db.insert("notes", null, v)
    }

    fun convos(): List<Convo> {
        val map = LinkedHashMap<String, Convo>()
        readableDatabase.rawQuery(
            "SELECT pkg, convo, text, time, grp, unread FROM notes ORDER BY time DESC LIMIT 3000", null
        ).use { c ->
            while (c.moveToNext()) {
                val pkg = c.getString(0)
                val name = c.getString(1)
                val key = pkg + "\u0000" + name
                val unread = if (c.getInt(5) == 1) 1 else 0
                val old = map[key]
                if (old == null) {
                    map[key] = Convo(pkg, name, c.getString(2), c.getLong(3), c.getInt(4) == 1, unread)
                } else if (unread == 1) {
                    map[key] = old.copy(unread = old.unread + 1)
                }
            }
        }
        return map.values.toList()
    }

    fun markRead(pkg: String, convo: String) {
        val v = ContentValues()
        v.put("unread", 0)
        writableDatabase.update("notes", v, "pkg=? AND convo=?", arrayOf(pkg, convo))
    }

    fun markAllRead() {
        val v = ContentValues()
        v.put("unread", 0)
        writableDatabase.update("notes", v, null, null)
    }

    fun clear() {
        writableDatabase.delete("notes", null, null)
    }

    fun deleteOlderThan(ms: Long) {
        writableDatabase.delete("notes", "time<?", arrayOf(ms.toString()))
    }

    fun countSince(ms: Long): Int =
        readableDatabase.rawQuery("SELECT COUNT(*) FROM notes WHERE time>=?", arrayOf(ms.toString()))
            .use { if (it.moveToFirst()) it.getInt(0) else 0 }

    companion object {
        @Volatile private var inst: NotificationStore? = null
        fun get(c: Context): NotificationStore =
            inst ?: synchronized(this) {
                inst ?: NotificationStore(c.applicationContext).also { inst = it }
            }
    }
}
