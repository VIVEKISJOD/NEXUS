package com.nexus.app

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Application = app
    val settings: AppSettings = AppSettings.get(app)
    private val store: NotificationStore = NotificationStore.get(app)

    var usageAccess by mutableStateOf(false)
        private set
    var notifAccess by mutableStateOf(false)
        private set
    var canInstall by mutableStateOf(true)
        private set
    var usage by mutableStateOf<UsageSummary?>(null)
        private set
    var convos by mutableStateOf<List<Convo>>(emptyList())
        private set
    var notesToday by mutableStateOf(0)
        private set
    var update by mutableStateOf<UpdateState>(UpdateState.Idle)
        private set

    init {
        cleanOld()
        if (settings.autoUpdate) checkUpdate(false)
    }

    fun onResume() {
        usageAccess = UsageRepo.hasAccess(ctx)
        notifAccess = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
        canInstall = ctx.packageManager.canRequestPackageInstalls()
        refreshUsage()
        refreshInbox()
    }

    fun refreshUsage() {
        if (!usageAccess) {
            usage = null
            return
        }
        viewModelScope.launch {
            val r = try {
                withContext(Dispatchers.IO) { UsageRepo.summary(ctx) }
            } catch (e: Exception) {
                null
            }
            usage = r
        }
    }

    fun refreshInbox() {
        viewModelScope.launch {
            try {
                val r = withContext(Dispatchers.IO) {
                    Pair(store.convos(), store.countSince(UsageRepo.dayStart(0)))
                }
                convos = r.first
                notesToday = r.second
            } catch (e: Exception) {
                // keep old list
            }
        }
    }

    fun cleanOld() {
        val days = settings.keepDays
        if (days <= 0) return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                store.deleteOlderThan(System.currentTimeMillis() - days * 86_400_000L)
            } catch (e: Exception) {
            }
        }
    }

    fun markRead(c: Convo) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { store.markRead(c.pkg, c.name) }
            refreshInbox()
        }
    }

    fun markAllRead() {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { store.markAllRead() }
            refreshInbox()
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { store.clear() }
            refreshInbox()
        }
    }

    fun checkUpdate(manual: Boolean) {
        val u = update
        if (u is UpdateState.Checking || u is UpdateState.Downloading) return
        update = UpdateState.Checking
        viewModelScope.launch {
            update = try {
                val info = Updater.check()
                if (info.build > BuildConfig.VERSION_CODE) UpdateState.Available(info) else UpdateState.UpToDate
            } catch (e: Exception) {
                if (manual) UpdateState.Error(e.message ?: "Could not check for updates") else UpdateState.Idle
            }
        }
    }

    fun startDownload(info: UpdateInfo) {
        update = UpdateState.Downloading(0)
        viewModelScope.launch {
            try {
                val f = Updater.download(ctx, info) { p -> update = UpdateState.Downloading(p) }
                update = UpdateState.Ready(f)
                installNow(f)
            } catch (e: Exception) {
                update = UpdateState.Error(e.message ?: "Download failed")
            }
        }
    }

    fun installNow(f: File) {
        try {
            canInstall = Updater.install(ctx, f)
        } catch (e: Exception) {
            update = UpdateState.Error(e.message ?: "Could not start the installer")
        }
    }
}
