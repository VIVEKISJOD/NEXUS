Step 1: Home usage dashboard, Inbox from notifications, Social shortcuts, Settings, and in-app updates.
